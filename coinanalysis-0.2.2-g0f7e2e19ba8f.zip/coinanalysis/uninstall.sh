#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

log() {
    printf '[coinanalysis] %s\n' "$*"
}

die() {
    printf '[coinanalysis] ERROR: %s\n' "$*" >&2
    exit 1
}

[[ "$(id -u)" -eq 0 ]] || die "run as root, for example: sudo ./uninstall.sh"
[[ "$SCRIPT_DIR" == /root/coinanalysis ]] \
    || die "refusing to remove an unexpected installation directory: $SCRIPT_DIR"
command -v docker >/dev/null 2>&1 || die "Docker is unavailable; no files were removed"
docker info >/dev/null 2>&1 || die "Docker daemon is not running; no files were removed"

printf '%s\n' \
    "This will stop and remove Coinanalysis containers, remove its unused local app image," \
    "and permanently delete this installation directory, including .env, data, and backups:" \
    "  $SCRIPT_DIR" \
    "Nginx Proxy Manager, the shared Docker network, and the Freqtrade base image will remain." \
    "Type coinanalysis to continue: "
IFS= read -r confirmation || true
[[ "${confirmation:-}" == coinanalysis ]] || {
    log "uninstall cancelled; no changes were made"
    exit 0
}

container_ids_output="$(docker ps --all --quiet \
    --filter 'label=com.docker.compose.project=coinanalysis' \
    --filter "label=com.docker.compose.project.working_dir=$SCRIPT_DIR")" \
    || die "could not identify Coinanalysis containers; installation files were kept"
local_image_ids_output="$(docker image ls --quiet coinanalysis)" \
    || die "could not list local Coinanalysis images; installation files were kept"

declare -A seen_image_ids=()
unique_image_ids=()
add_image_id() {
    local image_ref=$1
    local image_id
    [[ -n "$image_ref" ]] || return 0
    image_id="$(docker image inspect --format '{{.Id}}' "$image_ref" 2>/dev/null)" || return 0
    [[ -n "$image_id" ]] || return 0
    [[ -n "${seen_image_ids[$image_id]:-}" ]] && return 0
    seen_image_ids["$image_id"]=1
    unique_image_ids+=("$image_id")
}

while IFS= read -r image_ref; do
    add_image_id "$image_ref"
done <<< "$local_image_ids_output"

container_ids=()
while IFS= read -r container_id; do
    [[ -n "$container_id" ]] || continue
    container_ids+=("$container_id")
    container_image="$(docker inspect --format '{{.Image}}' "$container_id")" \
        || die "could not inspect Coinanalysis container $container_id; installation files were kept"
    add_image_id "$container_image"
done <<< "$container_ids_output"

log "stopping and removing Coinanalysis containers"
for container_id in "${container_ids[@]}"; do
    docker rm --force "$container_id" >/dev/null \
        || die "could not remove Coinanalysis container $container_id; installation files were kept"
done

for image_id in "${unique_image_ids[@]}"; do
    other_containers="$(docker ps --all --quiet --filter "ancestor=$image_id")" || {
        log "keeping app image $image_id because its usage could not be checked"
        continue
    }
    if [[ -n "$other_containers" ]]; then
        log "keeping app image $image_id because another container uses it"
    else
        log "removing unused app image $image_id"
        docker image rm "$image_id" >/dev/null \
            || log "could not remove app image $image_id; continuing with directory cleanup"
    fi
done

log "removing installation directory and all local data"
rm -rf -- "$SCRIPT_DIR"
printf '[coinanalysis] uninstall complete\n'
