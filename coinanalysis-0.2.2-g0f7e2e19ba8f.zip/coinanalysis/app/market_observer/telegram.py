from __future__ import annotations

import logging

import httpx

LOGGER = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, bot_token: str, chat_id: str, timeout_seconds: float = 15.0):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.timeout_seconds = timeout_seconds

    @property
    def enabled(self) -> bool:
        return bool(self.bot_token and self.chat_id)

    def send(self, message: str) -> bool:
        if not self.enabled:
            return False
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        try:
            response = httpx.post(
                url,
                data={"chat_id": self.chat_id, "text": message, "disable_web_page_preview": "true"},
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
            return True
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Telegram notification failed: %s", exc)
            return False
