from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import duckdb
import pandas as pd


class Storage:
    def __init__(self, path: str | Path, read_only: bool = False):
        self.path = str(path)
        self.read_only = read_only
        if not read_only:
            self._initialize()

    def _connect(self) -> duckdb.DuckDBPyConnection:
        return duckdb.connect(self.path, read_only=self.read_only)

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS candles (
                    symbol VARCHAR,
                    timeframe VARCHAR,
                    timestamp TIMESTAMPTZ,
                    open DOUBLE,
                    high DOUBLE,
                    low DOUBLE,
                    close DOUBLE,
                    volume DOUBLE,
                    source VARCHAR,
                    PRIMARY KEY (symbol, timeframe, timestamp)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS indicators (
                    symbol VARCHAR,
                    timeframe VARCHAR,
                    timestamp TIMESTAMPTZ,
                    close DOUBLE,
                    ema50 DOUBLE,
                    ema200 DOUBLE,
                    rsi14 DOUBLE,
                    atr14 DOUBLE,
                    atr_pct DOUBLE,
                    realized_vol DOUBLE,
                    volume_z DOUBLE,
                    PRIMARY KEY (symbol, timeframe, timestamp)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS external_metrics (
                    metric VARCHAR,
                    timestamp TIMESTAMPTZ,
                    value DOUBLE,
                    value_text VARCHAR,
                    source VARCHAR,
                    PRIMARY KEY (metric, timestamp)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS scores (
                    symbol VARCHAR,
                    timeframe VARCHAR,
                    timestamp TIMESTAMPTZ,
                    score DOUBLE,
                    state VARCHAR,
                    components_json VARCHAR,
                    reasons_json VARCHAR,
                    close DOUBLE,
                    PRIMARY KEY (symbol, timeframe, timestamp)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS alert_events (
                    alert_key VARCHAR PRIMARY KEY,
                    sent_at TIMESTAMPTZ,
                    message VARCHAR
                )
                """
            )

    @staticmethod
    def _timestamp(value: Any) -> pd.Timestamp:
        result = pd.Timestamp(value)
        return result.tz_localize("UTC") if result.tzinfo is None else result.tz_convert("UTC")

    def upsert_candles(self, frame: pd.DataFrame, symbol: str, timeframe: str, source: str) -> int:
        if frame.empty:
            return 0
        data = frame[["timestamp", "open", "high", "low", "close", "volume"]].copy()
        data.insert(0, "symbol", symbol)
        data.insert(1, "timeframe", timeframe)
        data["source"] = source
        data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True)
        with self._connect() as connection:
            connection.register("incoming_candles", data)
            connection.execute(
                """
                INSERT INTO candles SELECT * FROM incoming_candles
                ON CONFLICT (symbol, timeframe, timestamp) DO UPDATE SET
                    open = excluded.open, high = excluded.high, low = excluded.low,
                    close = excluded.close, volume = excluded.volume, source = excluded.source
                """
            )
        return len(data)

    def load_candles(self, symbol: str, timeframe: str, limit: int = 1000) -> pd.DataFrame:
        with self._connect() as connection:
            result = connection.execute(
                """
                SELECT timestamp, open, high, low, close, volume
                FROM candles WHERE symbol = ? AND timeframe = ?
                ORDER BY timestamp DESC LIMIT ?
                """,
                [symbol, timeframe, limit],
            ).fetch_df()
        return result.sort_values("timestamp") if not result.empty else result

    def export_candles_parquet(
        self, symbol: str, timeframe: str, directory: str | Path, limit: int = 100_000
    ) -> Path | None:
        frame = self.load_candles(symbol, timeframe, limit=limit)
        if frame.empty:
            return None
        target_dir = Path(directory)
        target_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{symbol.replace('/', '_')}_{timeframe}.parquet"
        target = target_dir / filename
        temporary = target.with_suffix(".parquet.tmp")
        frame.to_parquet(temporary, index=False, engine="pyarrow")
        temporary.replace(target)
        return target

    def upsert_indicators(self, frame: pd.DataFrame, symbol: str, timeframe: str) -> int:
        if frame.empty:
            return 0
        columns = [
            "timestamp",
            "close",
            "ema50",
            "ema200",
            "rsi14",
            "atr14",
            "atr_pct",
            "realized_vol",
            "volume_z",
        ]
        data = frame[columns].copy()
        data.insert(0, "symbol", symbol)
        data.insert(1, "timeframe", timeframe)
        data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True)
        with self._connect() as connection:
            connection.register("incoming_indicators", data)
            connection.execute(
                """
                INSERT INTO indicators SELECT * FROM incoming_indicators
                ON CONFLICT (symbol, timeframe, timestamp) DO UPDATE SET
                    close = excluded.close, ema50 = excluded.ema50, ema200 = excluded.ema200,
                    rsi14 = excluded.rsi14, atr14 = excluded.atr14, atr_pct = excluded.atr_pct,
                    realized_vol = excluded.realized_vol, volume_z = excluded.volume_z
                """
            )
        return len(data)

    def upsert_external(self, values: dict[str, float | str | None], source: str) -> None:
        if not values:
            return
        now = datetime.now(UTC)
        rows = []
        for metric, value in values.items():
            numeric = float(value) if isinstance(value, (int, float)) else None
            text = None if numeric is not None else str(value) if value is not None else None
            rows.append((metric, now, numeric, text, source))
        with self._connect() as connection:
            connection.executemany(
                """
                INSERT INTO external_metrics VALUES (?, ?, ?, ?, ?)
                ON CONFLICT (metric, timestamp) DO UPDATE SET
                    value = excluded.value,
                    value_text = excluded.value_text,
                    source = excluded.source
                """,
                rows,
            )

    def latest_external(self) -> pd.DataFrame:
        with self._connect() as connection:
            return connection.execute(
                """
                SELECT metric, timestamp, value, value_text, source
                FROM (
                    SELECT *, ROW_NUMBER() OVER (
                        PARTITION BY metric ORDER BY timestamp DESC
                    ) AS row_number
                    FROM external_metrics
                ) WHERE row_number = 1 ORDER BY metric
                """
            ).fetch_df()

    def insert_score(self, symbol: str, timeframe: str, result: dict[str, Any]) -> None:
        timestamp = self._timestamp(result["timestamp"])
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO scores VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (symbol, timeframe, timestamp) DO UPDATE SET
                    score = excluded.score, state = excluded.state,
                    components_json = excluded.components_json,
                    reasons_json = excluded.reasons_json,
                    close = excluded.close
                """,
                [
                    symbol,
                    timeframe,
                    timestamp.to_pydatetime(),
                    result["score"],
                    result["state"],
                    json.dumps(result["components"], sort_keys=True),
                    json.dumps(result["reasons"], ensure_ascii=True),
                    result["close"],
                ],
            )

    def latest_scores(self) -> pd.DataFrame:
        with self._connect() as connection:
            return connection.execute(
                """
                SELECT symbol, timeframe, timestamp, score, state,
                    components_json, reasons_json, close
                FROM (
                    SELECT *, ROW_NUMBER() OVER (
                        PARTITION BY symbol, timeframe ORDER BY timestamp DESC
                    ) AS row_number
                    FROM scores
                ) WHERE row_number = 1 ORDER BY symbol, timeframe
                """
            ).fetch_df()

    def latest_score(self, symbol: str, timeframe: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT timestamp, score, state, components_json, reasons_json, close
                FROM scores WHERE symbol = ? AND timeframe = ?
                ORDER BY timestamp DESC LIMIT 1
                """,
                [symbol, timeframe],
            ).fetchone()
        if not row:
            return None
        return {
            "timestamp": row[0],
            "score": row[1],
            "state": row[2],
            "components": json.loads(row[3]),
            "reasons": json.loads(row[4]),
            "close": row[5],
        }

    def should_send_alert(self, key: str, cooldown_seconds: int) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT sent_at FROM alert_events WHERE alert_key = ?", [key]
            ).fetchone()
        if not row:
            return True
        sent_at = self._timestamp(row[0]).to_pydatetime()
        return datetime.now(UTC) - sent_at >= timedelta(seconds=cooldown_seconds)

    def record_alert(self, key: str, message: str) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO alert_events VALUES (?, ?, ?)
                ON CONFLICT (alert_key) DO UPDATE SET
                    sent_at = excluded.sent_at, message = excluded.message
                """,
                [key, datetime.now(UTC), message],
            )

    def prune(self, days: int = 730) -> None:
        cutoff = datetime.now(UTC) - timedelta(days=days)
        with self._connect() as connection:
            connection.execute(
                "DELETE FROM candles WHERE timestamp < ? AND timeframe IN ('1m', '5m')",
                [cutoff],
            )
            connection.execute(
                "DELETE FROM indicators WHERE timestamp < ? AND timeframe IN ('1m', '5m')",
                [cutoff],
            )
