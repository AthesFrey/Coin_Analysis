from __future__ import annotations

import argparse
import logging
import time

from .alerts import AlertService
from .build_info import version_text
from .config import Settings
from .indicators import add_indicators, score_market
from .sources import PublicDataSources
from .storage import Storage
from .telegram import TelegramNotifier

LOGGER = logging.getLogger(__name__)


class Collector:
    def __init__(self, settings: Settings):
        settings.ensure_directories()
        self.settings = settings
        self.storage = Storage(settings.db_path)
        self.sources = PublicDataSources(settings.exchange_ids, settings.http_timeout_seconds)
        self.notifier = TelegramNotifier(
            settings.telegram_bot_token,
            settings.telegram_chat_id,
            settings.http_timeout_seconds,
        )
        self.alerts = AlertService(self.storage, self.notifier, settings.alert_cooldown_seconds)

    def close(self) -> None:
        self.sources.close()

    def collect_once(self) -> dict[str, int]:
        counts = {"candles": 0, "indicators": 0, "scores": 0, "external": 0, "errors": 0}
        fear_greed, fear_greed_label = self.sources.fetch_fear_greed(self.settings.fear_greed_url)
        external = self.sources.fetch_mempool(self.settings.mempool_base_url)
        if fear_greed is not None:
            external["fear_greed"] = fear_greed
            external["fear_greed_label"] = fear_greed_label or ""
        if external:
            self.storage.upsert_external(external, "alternative.me/mempool.space")
            counts["external"] = len(external)
            fastest_fee = external.get("btc_fee_fastest")
            if isinstance(fastest_fee, (float, int)):
                self.alerts.external_event(
                    "btc_fee_fastest", float(fastest_fee), self.settings.btc_fee_alert_threshold
                )

        for symbol in self.settings.symbols:
            derivatives = self.sources.fetch_derivatives(symbol)
            if derivatives:
                self.storage.upsert_external(derivatives, "ccxt-public-derivatives")
                counts["external"] += len(derivatives)

        summary: list[tuple[str, str, dict[str, object]]] = []
        for symbol in self.settings.symbols:
            for timeframe in self.settings.timeframes:
                try:
                    candles, source = self.sources.fetch_ohlcv(
                        symbol, timeframe, limit=self.settings.history_limit
                    )
                    counts["candles"] += self.storage.upsert_candles(
                        candles, symbol, timeframe, source
                    )
                    self.storage.export_candles_parquet(
                        symbol, timeframe, self.settings.data_dir / "parquet"
                    )
                    indicators = add_indicators(candles)
                    counts["indicators"] += self.storage.upsert_indicators(
                        indicators, symbol, timeframe
                    )
                    current = score_market(indicators, fear_greed)
                    previous = self.storage.latest_score(symbol, timeframe)
                    self.storage.insert_score(symbol, timeframe, current)
                    self.alerts.score_change(symbol, timeframe, current, previous)
                    realized_vol = current.get("realized_vol")
                    if isinstance(realized_vol, (float, int)):
                        self.alerts.volatility_event(symbol, timeframe, float(realized_vol))
                    summary.append((symbol, timeframe, current))
                    counts["scores"] += 1
                except Exception as exc:  # noqa: BLE001 - keep other symbols collecting
                    counts["errors"] += 1
                    LOGGER.warning("collection failed for %s %s: %s", symbol, timeframe, exc)
        if counts["errors"]:
            self.alerts.data_health(counts["errors"])
        self.alerts.daily_summary(summary)
        self.storage.prune()
        return counts

    def run(self, once: bool = False) -> None:
        while True:
            started = time.monotonic()
            counts = self.collect_once()
            LOGGER.info("collection completed: %s", counts)
            if once:
                return
            elapsed = time.monotonic() - started
            time.sleep(max(1, self.settings.collection_interval_seconds - elapsed))


def main() -> None:
    parser = argparse.ArgumentParser(description="Collect public market and BTC network metrics")
    parser.add_argument("--once", action="store_true", help="run one cycle and exit")
    args = parser.parse_args()
    settings = Settings.from_env()
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    collector = Collector(settings)
    try:
        LOGGER.info("starting %s", version_text())
        collector.run(once=args.once)
    finally:
        collector.close()


if __name__ == "__main__":
    main()
