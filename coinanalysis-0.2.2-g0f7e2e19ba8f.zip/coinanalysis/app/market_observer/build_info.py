"""Build and source version information exposed by the application."""

from __future__ import annotations

import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

VERSION = '0.2.2'
COMMIT_SHA = '0f7e2e19ba8fcacfba739d7fc103392ecfe117f5'
COMMIT_SHORT_SHA = '0f7e2e19ba8f'
BUILD_SOURCE = "git-commit"
BUILD_TIMESTAMP = '2026-10-25T12:32:40+00:00'
SOURCE_DATE_EPOCH: int | None = 1792931560


def _repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _git_sha() -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(_repository_root()), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    value = result.stdout.strip()
    return value or None


def current_commit_sha() -> str:
    if COMMIT_SHA != "unknown":
        return COMMIT_SHA
    configured = os.getenv("COINANALYSIS_COMMIT_SHA", "").strip()
    return configured or _git_sha() or "unknown"


def current_source() -> str:
    if COMMIT_SHA != "unknown":
        return BUILD_SOURCE
    return "environment" if os.getenv("COINANALYSIS_COMMIT_SHA") else BUILD_SOURCE


def version_text() -> str:
    details = [f"commit {current_commit_sha()}", f"source {current_source()}"]
    if BUILD_TIMESTAMP:
        details.append(f"built {BUILD_TIMESTAMP}")
    return f"coinanalysis {VERSION} ({'; '.join(details)})"


def build_info() -> dict[str, int | str | None]:
    timestamp = SOURCE_DATE_EPOCH
    if timestamp is None and BUILD_TIMESTAMP:
        timestamp = int(datetime.fromisoformat(BUILD_TIMESTAMP).replace(tzinfo=UTC).timestamp())
    return {
        "version": VERSION,
        "commit_sha": current_commit_sha(),
        "commit_short_sha": COMMIT_SHORT_SHA,
        "build_source": current_source(),
        "build_timestamp": BUILD_TIMESTAMP or None,
        "source_date_epoch": timestamp,
    }
