from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False, min_periods=period).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    average_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    average_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    relative_strength = average_gain / average_loss.replace(0, np.nan)
    result = 100 - (100 / (1 + relative_strength))
    flat_value = np.where(average_gain > 0, 100.0, 50.0)
    return result.where(average_loss.ne(0), flat_value).fillna(50.0)


def atr(frame: pd.DataFrame, period: int = 14) -> pd.Series:
    previous_close = frame["close"].shift(1)
    true_range = pd.concat(
        [
            frame["high"] - frame["low"],
            (frame["high"] - previous_close).abs(),
            (frame["low"] - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def add_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"timestamp", "open", "high", "low", "close", "volume"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"missing candle columns: {sorted(missing)}")

    result = frame.copy().sort_values("timestamp").drop_duplicates("timestamp")
    result["ema50"] = ema(result["close"], 50)
    result["ema200"] = ema(result["close"], 200)
    result["rsi14"] = rsi(result["close"], 14)
    result["atr14"] = atr(result, 14)
    result["atr_pct"] = result["atr14"] / result["close"]
    result["return_1"] = result["close"].pct_change()
    result["realized_vol"] = result["return_1"].rolling(24, min_periods=12).std() * np.sqrt(24)
    volume_mean = result["volume"].rolling(30, min_periods=10).mean()
    volume_std = result["volume"].rolling(30, min_periods=10).std()
    result["volume_z"] = (result["volume"] - volume_mean) / volume_std.replace(0, np.nan)
    result["volume_z"] = result["volume_z"].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return result


def _bounded(value: float | None, low: float = 0.0, high: float = 1.0) -> float | None:
    if value is None or not np.isfinite(value):
        return None
    return float(np.clip(value, low, high))


def score_market(frame: pd.DataFrame, fear_greed: float | None = None) -> dict[str, Any]:
    if frame.empty:
        raise ValueError("cannot score an empty candle frame")
    latest = frame.iloc[-1]
    components: dict[str, float] = {}
    reasons: list[str] = []

    close = float(latest["close"])
    ema50 = latest.get("ema50")
    ema200 = latest.get("ema200")
    if pd.notna(ema50) and pd.notna(ema200):
        if close > float(ema200) and float(ema50) > float(ema200):
            components["trend"] = 1.0
            reasons.append("price and EMA50 are above EMA200")
        elif close < float(ema200) and float(ema50) < float(ema200):
            components["trend"] = 0.0
            reasons.append("price and EMA50 are below EMA200")
        else:
            components["trend"] = 0.5
            reasons.append("trend averages are mixed")

    rsi_value = _bounded(float(latest["rsi14"]) if pd.notna(latest["rsi14"]) else None, 0, 100)
    if rsi_value is not None:
        momentum_score = _bounded((rsi_value - 30) / 40)
        components["momentum"] = 0.5 if momentum_score is None else momentum_score
        if rsi_value >= 75:
            reasons.append("momentum is overheated")
        elif rsi_value <= 35:
            reasons.append("momentum is weak")

    volatility = float(latest["realized_vol"]) if pd.notna(latest["realized_vol"]) else None
    if volatility is not None:
        volatility_score = _bounded(1 - volatility / 0.8)
        components["volatility"] = 0.0 if volatility_score is None else volatility_score
        if volatility > 0.8:
            reasons.append("realized volatility is elevated")

    volume_z = float(latest["volume_z"]) if pd.notna(latest["volume_z"]) else 0.0
    volume_score = _bounded(0.5 + volume_z * 0.12)
    components["volume"] = 0.5 if volume_score is None else volume_score
    if volume_z >= 2:
        reasons.append("volume is unusually high")

    if fear_greed is not None and np.isfinite(fear_greed):
        fear_greed_score = _bounded(float(fear_greed) / 100)
        components["fear_greed"] = 0.5 if fear_greed_score is None else fear_greed_score
        if fear_greed <= 25:
            reasons.append("Fear & Greed reports extreme fear")
        elif fear_greed >= 75:
            reasons.append("Fear & Greed reports extreme greed")

    weights = {
        "trend": 0.35,
        "momentum": 0.20,
        "volatility": 0.15,
        "volume": 0.10,
        "fear_greed": 0.20,
    }
    available_weight = sum(weights[name] for name in components)
    score = 50.0 if not available_weight else sum(
        components[name] * weight for name, weight in weights.items() if name in components
    ) / available_weight * 100
    score = round(float(np.clip(score, 0, 100)), 2)
    state = "risk-on" if score >= 65 else "risk-off" if score <= 35 else "neutral"
    if not reasons:
        reasons.append("insufficient history for indicator explanations")
    return {
        "score": score,
        "state": state,
        "components": components,
        "reasons": reasons,
        "close": close,
        "realized_vol": volatility,
        "volume_z": volume_z,
        "timestamp": latest["timestamp"],
    }
