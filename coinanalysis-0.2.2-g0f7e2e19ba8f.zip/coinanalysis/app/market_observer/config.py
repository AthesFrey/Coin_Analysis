from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


def _csv(value: str, default: tuple[str, ...]) -> tuple[str, ...]:
    values = tuple(item.strip() for item in value.split(",") if item.strip())
    return values or default


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    db_path: Path
    timezone: str
    log_level: str
    exchange_ids: tuple[str, ...]
    symbols: tuple[str, ...]
    timeframes: tuple[str, ...]
    history_limit: int
    collection_interval_seconds: int
    http_timeout_seconds: float
    telegram_bot_token: str
    telegram_chat_id: str
    alert_cooldown_seconds: int
    btc_fee_alert_threshold: float
    fear_greed_url: str = "https://api.alternative.me/fng/?limit=1"
    mempool_base_url: str = "https://mempool.space/api"

    @classmethod
    def from_env(cls, env_file: str | Path | None = None) -> Settings:
        if env_file:
            load_dotenv(env_file)
        else:
            load_dotenv()

        data_dir = Path(os.getenv("DATA_DIR", "/data"))
        db_path = Path(os.getenv("DB_PATH", str(data_dir / "market.duckdb")))
        return cls(
            data_dir=data_dir,
            db_path=db_path,
            timezone=os.getenv("TZ", "Asia/Shanghai"),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
            exchange_ids=_csv(os.getenv("EXCHANGE_IDS", "kraken,coinbase"), ("kraken",)),
            symbols=_csv(os.getenv("SYMBOLS", "BTC/USDT,ETH/USDT"), ("BTC/USDT", "ETH/USDT")),
            timeframes=_csv(os.getenv("TIMEFRAMES", "1h,4h,1d"), ("1h", "4h", "1d")),
            history_limit=max(100, int(os.getenv("HISTORY_LIMIT", "500"))),
            collection_interval_seconds=max(60, int(os.getenv("COLLECT_INTERVAL_SECONDS", "900"))),
            http_timeout_seconds=max(2.0, float(os.getenv("HTTP_TIMEOUT_SECONDS", "15"))),
            telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
            telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID", "").strip(),
            alert_cooldown_seconds=max(60, int(os.getenv("ALERT_COOLDOWN_SECONDS", "3600"))),
            btc_fee_alert_threshold=max(1.0, float(os.getenv("BTC_FEE_ALERT_THRESHOLD", "100"))),
        )

    def ensure_directories(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
