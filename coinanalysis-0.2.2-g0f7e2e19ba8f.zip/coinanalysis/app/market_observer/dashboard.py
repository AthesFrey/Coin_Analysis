from __future__ import annotations

import json
import os

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from market_observer.build_info import version_text
from market_observer.config import Settings
from market_observer.storage import Storage

st.set_page_config(page_title="BTC/ETH Market Observer", layout="wide")
settings = Settings.from_env()

st.title("BTC/ETH Market Observer")
st.caption(
    "Read-only indicators. Scores describe current conditions; they do not predict price. "
    f"{version_text()}"
)

if not settings.db_path.exists():
    st.warning("No data yet. Start the collector and refresh this page after the first cycle.")
    st.stop()

storage = Storage(settings.db_path, read_only=True)
scores = storage.latest_scores()
external = storage.latest_external()

if scores.empty:
    st.warning("No data yet. Start the collector and refresh this page after the first cycle.")
    st.stop()

cards = st.columns(max(1, len(scores)))
for card, (_, row) in zip(cards, scores.iterrows()):
    with card:
        state = str(row["state"])
        card.metric(f"{row['symbol']} · {row['timeframe']}", f"{row['score']:.1f}", state)
        card.caption(f"Last close: {row['close']:.6g}")

overview, chart, data = st.tabs(["Overview", "Chart", "Data"])

with overview:
    table = scores[["symbol", "timeframe", "timestamp", "score", "state", "close"]].copy()
    table["timestamp"] = pd.to_datetime(table["timestamp"], utc=True).dt.tz_convert(
        settings.timezone
    )
    st.dataframe(table, use_container_width=True, hide_index=True)
    if not external.empty:
        external_view = external.copy()
        external_view["timestamp"] = pd.to_datetime(
            external_view["timestamp"], utc=True
        ).dt.tz_convert(settings.timezone)
        st.subheader("External metrics")
        st.dataframe(external_view, use_container_width=True, hide_index=True)

    st.subheader("Score reasons")
    for _, row in scores.iterrows():
        reasons = json.loads(row["reasons_json"])
        components = json.loads(row["components_json"])
        st.markdown(f"**{row['symbol']} {row['timeframe']} · {row['state']}**")
        st.write("; ".join(reasons))
        st.json(components, expanded=False)

with chart:
    symbol = st.selectbox("Symbol", list(settings.symbols))
    timeframe = st.selectbox("Timeframe", list(settings.timeframes))
    candles = storage.load_candles(symbol, timeframe, 500)
    if candles.empty:
        st.info("No candles for this selection yet.")
    else:
        candles["timestamp"] = pd.to_datetime(candles["timestamp"], utc=True).dt.tz_convert(
            settings.timezone
        )
        figure = go.Figure(
            data=[
                go.Candlestick(
                    x=candles["timestamp"],
                    open=candles["open"],
                    high=candles["high"],
                    low=candles["low"],
                    close=candles["close"],
                    name=symbol,
                )
            ]
        )
        figure.update_layout(height=600, xaxis_rangeslider_visible=False)
        st.plotly_chart(figure, use_container_width=True)

with data:
    st.download_button(
        "Download latest scores",
        data=scores.to_csv(index=False),
        file_name="latest_scores.csv",
        mime="text/csv",
    )
    st.code(f"Database: {os.path.abspath(settings.db_path)}")
