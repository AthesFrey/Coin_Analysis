from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from .storage import Storage
from .telegram import TelegramNotifier

LOGGER = logging.getLogger(__name__)


class AlertService:
    def __init__(self, storage: Storage, notifier: TelegramNotifier, cooldown_seconds: int):
        self.storage = storage
        self.notifier = notifier
        self.cooldown_seconds = cooldown_seconds

    def _send_once(self, key: str, message: str, cooldown_seconds: int | None = None) -> bool:
        cooldown = self.cooldown_seconds if cooldown_seconds is None else cooldown_seconds
        if not self.storage.should_send_alert(key, cooldown):
            return False
        sent = self.notifier.send(message)
        if sent:
            self.storage.record_alert(key, message)
        return sent

    def score_change(
        self,
        symbol: str,
        timeframe: str,
        current: dict[str, Any],
        previous: dict[str, Any] | None,
    ) -> bool:
        if previous is None:
            return False
        state_changed = current["state"] != previous["state"]
        threshold_changed = (previous["score"] < 65 <= current["score"]) or (
            previous["score"] >= 65 > current["score"]
        ) or (previous["score"] > 35 >= current["score"]) or (
            previous["score"] <= 35 < current["score"]
        )
        if not (state_changed or threshold_changed):
            return False
        reasons = "; ".join(current["reasons"][:3])
        message = (
            f"{symbol} {timeframe} market state: {current['state']}\n"
            f"Score: {current['score']:.1f} (was {previous['score']:.1f})\n"
            f"Close: {current['close']:.4g}\n"
            f"Why: {reasons}"
        )
        return self._send_once(f"score:{symbol}:{timeframe}:{current['state']}", message)

    def daily_summary(self, scores: list[tuple[str, str, dict[str, Any]]]) -> bool:
        if not scores:
            return False
        rows = ["BTC/ETH market summary"]
        for symbol, timeframe, score in scores:
            rows.append(f"{symbol} {timeframe}: {score['state']} {score['score']:.1f}")
        day = datetime.now(UTC).strftime("%Y-%m-%d")
        return self._send_once(f"daily-summary:{day}", "\n".join(rows), cooldown_seconds=86400)

    def external_event(self, metric: str, value: float, threshold: float) -> bool:
        if value < threshold:
            return False
        message = f"BTC network metric alert\n{metric}: {value:g} (threshold {threshold:g})"
        return self._send_once(f"external:{metric}", message)

    def volatility_event(
        self, symbol: str, timeframe: str, value: float, threshold: float = 0.8
    ) -> bool:
        if value < threshold:
            return False
        message = (
            f"Volatility alert\n{symbol} {timeframe} realized volatility: {value:.3f} "
            f"(threshold {threshold:.3f})"
        )
        return self._send_once(f"volatility:{symbol}:{timeframe}", message)

    def data_health(self, errors: int) -> bool:
        message = f"Market data health alert\n{errors} symbol/timeframe collection jobs failed."
        return self._send_once("data-health", message)
