"""Read-only market observation services."""

from .build_info import COMMIT_SHA, version_text
from .build_info import VERSION as __version__

__all__ = ["COMMIT_SHA", "__version__", "version_text"]
