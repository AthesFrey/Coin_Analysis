from __future__ import annotations

import argparse
from collections.abc import Sequence

from .build_info import version_text


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="coinanalysis",
        description="Read-only BTC and ETH market observer",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=version_text(),
        help="show the installed source version and commit",
    )
    parser.parse_args(argv)
    parser.print_help()
    return 0
