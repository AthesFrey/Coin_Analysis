from __future__ import annotations

import sys
from datetime import UTC, datetime, timedelta

from .build_info import version_text
from .config import Settings
from .storage import Storage


def main() -> int:
    settings = Settings.from_env()
    version = version_text()
    if not settings.db_path.exists():
        print(f"{version}: database has not been created yet")
        return 1
    storage = Storage(settings.db_path, read_only=True)
    scores = storage.latest_scores()
    if scores.empty:
        print(f"{version}: no scores collected yet")
        return 1
    newest = scores["timestamp"].max()
    newest = newest.to_pydatetime() if hasattr(newest, "to_pydatetime") else newest
    if newest.tzinfo is None:
        newest = newest.replace(tzinfo=UTC)
    age = datetime.now(UTC) - newest
    freshness_limit = max(settings.collection_interval_seconds * 3, 2 * 60 * 60)
    if age > timedelta(seconds=freshness_limit):
        print(f"{version}: latest score is stale: {age}")
        return 1
    print(f"{version_text()} healthy: {len(scores)} scores, newest {newest.isoformat()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
