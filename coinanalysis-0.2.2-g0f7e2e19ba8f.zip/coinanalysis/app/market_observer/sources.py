from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any

import ccxt
import httpx
import pandas as pd

LOGGER = logging.getLogger(__name__)


class PublicDataSources:
    def __init__(self, exchange_ids: tuple[str, ...], timeout_seconds: float = 15.0):
        self.timeout_seconds = timeout_seconds
        self.exchanges: list[tuple[str, Any]] = []
        for exchange_id in exchange_ids:
            exchange_type = getattr(ccxt, exchange_id, None)
            if exchange_type is None:
                LOGGER.warning("unknown ccxt exchange: %s", exchange_id)
                continue
            try:
                exchange = exchange_type(
                    {"enableRateLimit": True, "timeout": int(timeout_seconds * 1000)}
                )
                exchange.load_markets()
                self.exchanges.append((exchange_id, exchange))
            except Exception as exc:  # noqa: BLE001 - one unavailable source should not stop collection
                LOGGER.warning("could not initialize %s: %s", exchange_id, exc)
        self.http = httpx.Client(timeout=timeout_seconds, follow_redirects=True)

    def close(self) -> None:
        self.http.close()
        for _, exchange in self.exchanges:
            try:
                exchange.close()
            except Exception:  # noqa: BLE001
                pass

    def fetch_ohlcv(
        self, symbol: str, timeframe: str, limit: int = 500
    ) -> tuple[pd.DataFrame, str]:
        errors = []
        for exchange_id, exchange in self.exchanges:
            if symbol not in exchange.markets:
                continue
            try:
                rows = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
                frame = pd.DataFrame(
                    rows,
                    columns=["timestamp_ms", "open", "high", "low", "close", "volume"],
                )
                if frame.empty:
                    continue
                frame["timestamp"] = pd.to_datetime(frame.pop("timestamp_ms"), unit="ms", utc=True)
                for column in ["open", "high", "low", "close", "volume"]:
                    frame[column] = pd.to_numeric(frame[column], errors="coerce")
                frame = frame.dropna(subset=["timestamp", "open", "high", "low", "close", "volume"])
                return frame[["timestamp", "open", "high", "low", "close", "volume"]], exchange_id
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{exchange_id}: {exc}")
        raise RuntimeError(
            f"no public OHLCV source available for {symbol} {timeframe}: {'; '.join(errors)}"
        )

    def fetch_derivatives(self, symbol: str) -> dict[str, float]:
        """Read public funding/open-interest data when an exchange exposes it."""
        base, quote = symbol.split("/", 1)
        result: dict[str, float] = {}
        for exchange_id, exchange in self.exchanges:
            markets = getattr(exchange, "markets", {})
            candidates = [
                f"{base}/{quote}:USDT",
                f"{base}/{quote}:USD",
                symbol,
            ]
            derivative_symbol = next(
                (
                    candidate
                    for candidate in candidates
                    if candidate in markets and markets[candidate].get("contract")
                ),
                None,
            )
            if not derivative_symbol:
                continue
            try:
                if exchange.has.get("fetchFundingRate"):
                    funding = exchange.fetch_funding_rate(derivative_symbol)
                    rate = funding.get("fundingRate")
                    if rate is not None:
                        result[f"{base.lower()}_funding_rate"] = float(rate)
                if exchange.has.get("fetchOpenInterest"):
                    interest = exchange.fetch_open_interest(derivative_symbol)
                    value = interest.get("openInterestValue") or interest.get("openInterestAmount")
                    if value is not None:
                        result[f"{base.lower()}_open_interest"] = float(value)
            except Exception as exc:  # noqa: BLE001 - optional data must not stop spot collection
                LOGGER.info("derivatives unavailable for %s on %s: %s", symbol, exchange_id, exc)
            if result:
                break
        return result

    def _get_json(self, url: str) -> Any:
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                response = self.http.get(url)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as exc:
                last_error = exc
                status = exc.response.status_code
                if status < 500 and status != 429:
                    raise
            except httpx.HTTPError as exc:
                last_error = exc
            if attempt < 2:
                time.sleep(2**attempt)
        if last_error:
            raise last_error
        raise RuntimeError(f"request failed without an exception: {url}")

    def fetch_fear_greed(self, url: str) -> tuple[float | None, str | None]:
        try:
            payload = self._get_json(url)
            item = (payload.get("data") or [None])[0]
            if not item:
                return None, None
            value = float(item["value"])
            classification = str(item.get("value_classification", ""))
            return value, classification
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Fear & Greed unavailable: %s", exc)
            return None, None

    def fetch_mempool(self, base_url: str) -> dict[str, float | str]:
        result: dict[str, float | str] = {}
        try:
            fees = self._get_json(f"{base_url.rstrip('/')}/v1/fees/recommended")
            for source_key, metric in {
                "fastestFee": "btc_fee_fastest",
                "halfHourFee": "btc_fee_half_hour",
                "hourFee": "btc_fee_hour",
                "economyFee": "btc_fee_economy",
                "minimumFee": "btc_fee_minimum",
            }.items():
                if source_key in fees:
                    result[metric] = float(fees[source_key])
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Mempool fee data unavailable: %s", exc)
        try:
            mempool = self._get_json(f"{base_url.rstrip('/')}/mempool")
            for source_key, metric in {
                "count": "btc_mempool_count",
                "vsize": "btc_mempool_vsize",
            }.items():
                if source_key in mempool:
                    result[metric] = float(mempool[source_key])
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Mempool status unavailable: %s", exc)
        return result

    @staticmethod
    def now_utc() -> datetime:
        return datetime.now(UTC)
