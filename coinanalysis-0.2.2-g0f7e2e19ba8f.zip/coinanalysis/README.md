# Coinanalysis

Coinanalysis 是一个只读的 BTC/ETH 市场观察工具。Collector 从公开接口采集行情、Fear & Greed、BTC 网络费率和可用的公开衍生品指标，将历史数据保存在 DuckDB；Dashboard 展示趋势、动量、波动率、成交量和风险状态。

系统不使用交易所密钥，也没有真实下单能力。Freqtrade 用于 dry-run 策略观察，`freqtrade/config.json` 中的 `dry_run` 固定为 `true`。

## 服务和端口

| 服务 | 用途 | Docker 网络内地址 | 宿主机端口 |
| --- | --- | --- | --- |
| Dashboard | Coinanalysis 行情分析面板 | `dashboard:8695` | 不发布 |
| Freqtrade | dry-run 策略 UI/API，可选反代 | `freqtrade:8696` | 不发布 |
| Collector | 定时采集和计算指标 | 无 HTTP 服务 | 不发布 |

这是一个工具包，包含一个行情面板和一个可选的 Freqtrade 页面。`8695` 和 `8696` 是 Docker 网络内的不同服务端口，不是 VPS 公网端口，也不会直接映射到宿主机。

## VPS 要求

- Debian 或 Ubuntu，amd64 或 arm64，至少 4 GiB 可用磁盘空间。
- 已安装并运行 Docker Engine、Compose 插件、Buildx 插件和 OpenSSL。
- 已安装并运行 Nginx Proxy Manager（NPM），且与 Coinanalysis 使用同一台 VPS 上的 Docker Engine。
- 用 root 执行部署脚本；安装和升级时需要联网拉取镜像及 Python 依赖。

部署脚本不会安装 Docker 或 NPM。缺少 Docker 时会停止并显示以下官方安装命令：

```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh --dry-run
sh get-docker.sh
```

先确认 dry-run 输出，再执行安装命令。若 NPM 尚未安装或没有运行，也要先手动安装并启动 NPM，然后再运行 Coinanalysis 部署。

## 安装

将 ZIP 和同名 `.zip.sha256` 文件上传到 VPS 的 `/root`。文件名中的 `<shortsha>` 应替换为实际工具包文件名中的短 SHA：

```bash
cd /root
sha256sum -c coinanalysis-0.2.2-g<shortsha>.zip.sha256
unzip -o coinanalysis-0.2.2-g<shortsha>.zip -d /root
cd /root/coinanalysis
sudo ./deploy.sh
```

部署前会校验 ZIP 内容、Docker Engine、Compose、Buildx、NPM 容器和磁盘空间。NPM 必须在当前 Docker 主机上运行；脚本无法唯一识别 NPM、NPM 未运行或找到多个候选容器时，会退出且不会创建 `.env` 或启动 Coinanalysis。

确认唯一运行中的 NPM 后，脚本会创建外部 Docker 网络 `coinanalysis_proxy`（或 `.env` 中的 `PROXY_NETWORK`），自动把 NPM 接入该网络并验证连接。不会再要求手工执行 `docker network connect`。脚本随后生成 `.env` 和随机 Freqtrade API 凭据，将 `.env` 权限设为 `0600`，构建并启动三个服务。现有 `.env` 和 `data/` 会保留；每次部署会在 `.deploy-backups/` 保存现有配置和构建清单。

首次构建可能需要数分钟。部署成功时 Collector 应为 `healthy`，Dashboard 和 Freqtrade 应保持 `Up`。版本输出包含完整源码 commit SHA，可用以下命令查看：

```bash
cd /root/coinanalysis
sudo docker compose exec -T collector python -m market_observer --version
```

工具包内的 `BUILD-INFO.json` 和 `BUILD-MANIFEST.json` 也记录完整 SHA、版本、commit 时间、构建时间基准和文件 SHA-256。解压后可运行 `sudo ./verify.sh` 校验包内文件。

## NPM 反向代理

部署脚本已自动将 NPM 接入 `coinanalysis_proxy`。在 NPM 的 Proxy Hosts 页面创建以下规则，Scheme 都选 `http`：

| 域名 | Forward Hostname / IP | Forward Port | 设置 |
| --- | --- | --- | --- |
| `market.example.com` | `dashboard` | `8695` | 开启 Websockets Support；按需申请 HTTPS 证书 |
| `trade.example.com` | `freqtrade` | `8696` | 建议只在确有需要时创建；启用 HTTPS 和 Access List |

将示例域名替换成你自己的域名。Freqtrade API 不应无访问控制地暴露到公网；NPM 之外不要发布 `8695` 或 `8696`。如果只使用行情面板，只需创建 `market` 这一条 Proxy Host。

## 升级

先把新版 ZIP 和 `.zip.sha256` 上传到 `/root`，校验后覆盖解压，再运行部署脚本：

```bash
cd /root
sha256sum -c coinanalysis-0.2.2-g<shortsha>.zip.sha256
unzip -o coinanalysis-0.2.2-g<shortsha>.zip -d /root
cd /root/coinanalysis
sudo ./deploy.sh
```

ZIP 不含 `.env`、`data/` 或备份目录，因此覆盖解压不会覆盖配置和 DuckDB。部署脚本会重建 Coinanalysis 镜像并更新服务；不要手动删除 `data/`。失败时先运行 `docker compose ps -a` 和 `docker compose logs --tail=100 collector`，配置备份位于 `.deploy-backups/`。

回滚时将已验证的旧版 ZIP 解压到 `/root`，再运行 `sudo /root/coinanalysis/deploy.sh`。数据目录保持原样；如果旧版 Compose 配置也需要恢复，从对应 `.deploy-backups/` 中恢复 `compose.yaml` 和 `BUILD-MANIFEST.json`。

## 备份和恢复

备份期间先停止 Collector，避免复制 DuckDB 时仍有写入事务：

```bash
cd /root/coinanalysis
sudo docker compose stop collector
backup_file="/root/coinanalysis-backup-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
sudo tar -czf "$backup_file" .env data
sudo chmod 600 "$backup_file"
sudo docker compose start collector
```

备份文件包含 Freqtrade API 凭据，应下载到受控位置并限制访问。恢复时先停止所有服务，将备份解压到 `/root/coinanalysis`，确认 `.env` 权限为 `0600`，再运行 `sudo docker compose up -d`。

## 故障排查

检查服务和日志：

```bash
cd /root/coinanalysis
sudo docker compose ps -a
sudo docker compose logs --tail=100 dashboard freqtrade collector
```

从 NPM 容器检查上游连通性；HTTP 状态 `200` 表示该上游可访问：

```bash
sudo docker exec npm curl -fsS -o /dev/null -w '%{http_code}\n' http://dashboard:8695/
sudo docker exec npm curl -fsS -o /dev/null -w '%{http_code}\n' http://freqtrade:8696/api/v1/ping
```

若 NPM 容器名不是 `npm`，把命令中的 `npm` 换成实际容器名。若连接失败，确认 NPM 与 Coinanalysis 在同一 Docker 主机，并检查网络成员：

```bash
sudo docker network inspect coinanalysis_proxy --format '{{range .Containers}}{{println .Name}}{{end}}'
```

NPM 代理返回 502 时，核对 Proxy Host 的域名、Scheme `http`、目标主机名和端口，Dashboard 还要开启 Websockets Support。Freqtrade 容器持续重启时查看 `docker compose logs --tail=100 freqtrade`；只有服务保持 `Up` 后，NPM 才能连接到 `freqtrade:8696`。

若部署脚本报告找不到 NPM，请先确认 NPM 是运行中的 Docker 容器，且使用官方 `jc21/nginx-proxy-manager` 镜像或容器名为 `npm`。若检测到多个候选容器，先确定实际使用的一个并停止其他候选，再重试。

## 卸载

卸载会停止并删除 Coinanalysis 容器，删除未被其他容器使用的 Coinanalysis 应用镜像，并永久删除 `/root/coinanalysis` 中的 `.env`、DuckDB 数据、配置备份和工具包文件。Freqtrade 基础镜像、NPM 和共享 Docker 网络会保留。

```bash
cd /root/coinanalysis
sudo ./uninstall.sh
```

脚本要求输入 `coinanalysis` 才会继续。卸载前先把需要保留的备份复制到安装目录之外；确认后删除的数据不能由脚本恢复。

## 配置和资源

主要采集配置位于 `.env`。默认采集两个交易对、三个周期，每 15 分钟运行一次，每次请求最多 500 根历史 K 线。空的 Telegram 配置会关闭通知；系统只使用公开行情 API。

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PROXY_NETWORK` | `coinanalysis_proxy` | NPM 与 Coinanalysis 共用的 Docker 网络 |
| `EXCHANGE_IDS` | `kraken,coinbase` | 公开 CCXT 数据源 |
| `SYMBOLS` | `BTC/USDT,ETH/USDT` | 采集交易对 |
| `TIMEFRAMES` | `1h,4h,1d` | K 线周期 |
| `HISTORY_LIMIT` | `500` | 每次请求的历史 K 线数量 |
| `COLLECT_INTERVAL_SECONDS` | `900` | 采集间隔，最低 60 秒 |
| `TELEGRAM_BOT_TOKEN` | 空 | Telegram Bot Token；留空关闭提醒 |
| `TELEGRAM_CHAT_ID` | 空 | Telegram 目标会话 |

2 vCPU、4 GB RAM、70 GB 磁盘足以运行默认配置。Compose 为 Collector、Dashboard、Freqtrade 分别设置了内存和 CPU 上限，并对容器日志做轮转。建议将 DuckDB 备份到 VPS 之外，定期检查磁盘空间，并清理过期 Parquet 数据和不再使用的 Docker 镜像。不要在该 VPS 上同时运行大型回测任务。

评分描述当前市场条件，不是价格预测。分数不低于 65 为 `risk-on`，不高于 35 为 `risk-off`，其余为 `neutral`。数据按 UTC 保存，界面默认使用 `Asia/Shanghai` 时区。
