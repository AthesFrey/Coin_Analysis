#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$SCRIPT_DIR"

die() {
    printf 'coinanalysis package verification failed: %s\n' "$*" >&2
    exit 1
}

command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"

for required in BUILD-INFO.json BUILD-MANIFEST.json SHA256SUMS deploy.sh uninstall.sh verify.sh; do
    [[ -f "$required" ]] || die "missing required file: $required"
done

if awk '$2 == "SHA256SUMS" { found = 1 } END { exit !found }' SHA256SUMS; then
    die "SHA256SUMS cannot hash itself"
fi
sha256sum -c --strict SHA256SUMS

manifest_sha="$(sed -nE 's/^[[:space:]]*"commit_sha"[[:space:]]*:[[:space:]]*"([0-9a-f]{40})"[[:space:]]*,?[[:space:]]*$/\1/p' BUILD-MANIFEST.json | head -n 1)"
info_sha="$(sed -nE 's/^[[:space:]]*"commit_sha"[[:space:]]*:[[:space:]]*"([0-9a-f]{40})"[[:space:]]*,?[[:space:]]*$/\1/p' BUILD-INFO.json | head -n 1)"
[[ "$manifest_sha" =~ ^[0-9a-f]{40}$ ]] || die "BUILD-MANIFEST.json has no full commit SHA"
[[ "$info_sha" == "$manifest_sha" ]] || die "BUILD-INFO.json and BUILD-MANIFEST.json disagree"
grep -Eq '^[[:space:]]*"dirty"[[:space:]]*:[[:space:]]*false[[:space:]]*,?[[:space:]]*$' BUILD-MANIFEST.json \
    || die "BUILD-MANIFEST.json does not describe a clean source"

printf 'verified coinanalysis package commit %s\n' "$manifest_sha"
