import talib.abstract as ta
from freqtrade.strategy import IStrategy
from pandas import DataFrame


class RegimeStrategy(IStrategy):
    """Conservative spot strategy for dry-run research only."""

    timeframe = "1h"
    startup_candle_count = 240
    process_only_new_candles = True
    can_short = False
    minimal_roi = {"0": 0.05, "120": 0.02, "360": 0.0}
    stoploss = -0.15

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["ema50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["ema200"] = ta.EMA(dataframe, timeperiod=200)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_mean"] = dataframe["volume"].rolling(30).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe["close"] > dataframe["ema200"])
                & (dataframe["ema50"] > dataframe["ema200"])
                & (dataframe["rsi"] >= 50)
                & (dataframe["rsi"] <= 72)
                & (dataframe["volume"] > dataframe["volume_mean"] * 0.8)
            ),
            ["enter_long", "enter_tag"],
        ] = (1, "trend-regime")
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe["close"] < dataframe["ema50"])
                | (dataframe["rsi"] > 78)
                | (dataframe["volume"] <= 0)
            ),
            ["exit_long", "exit_tag"],
        ] = (1, "regime-break")
        return dataframe
