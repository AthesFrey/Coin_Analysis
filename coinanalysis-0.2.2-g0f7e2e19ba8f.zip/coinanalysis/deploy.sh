#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$SCRIPT_DIR"

readonly MIN_FREE_KB=4194304
readonly HEALTH_TIMEOUT_SECONDS=300
readonly SERVICE_START_TIMEOUT_SECONDS=60

log() {
    printf '[coinanalysis] %s\n' "$*"
}

die() {
    printf '[coinanalysis] ERROR: %s\n' "$*" >&2
    exit 1
}

on_error() {
    local code=$?
    printf '[coinanalysis] ERROR: deployment stopped at line %s (exit %s)\n' "${BASH_LINENO[0]:-?}" "$code" >&2
    exit "$code"
}
trap on_error ERR

require_command() {
    command -v "$1" >/dev/null 2>&1 || die "required command is missing: $1"
}

for command_name in awk bash chmod cp date df grep head id install mkdir sed sha256sum sleep uname; do
    require_command "$command_name"
done

[[ "$(id -u)" -eq 0 ]] || die "run as root, for example: sudo ./deploy.sh"
[[ "$SCRIPT_DIR" == /root/coinanalysis ]] \
    || die "place the package in /root/coinanalysis, then run sudo /root/coinanalysis/deploy.sh"
[[ "$(uname -s)" == Linux ]] || die "the deployment target must be Linux"
case "$(uname -m)" in
    x86_64|amd64|aarch64|arm64) ;;
    *) die "unsupported CPU architecture: $(uname -m); supported: amd64 and arm64" ;;
esac

for required in Dockerfile compose.yaml .env.example BUILD-INFO.json BUILD-MANIFEST.json verify.sh uninstall.sh; do
    [[ -f "$required" ]] || die "package is incomplete; missing $required"
done

available_kb="$(df -Pk "$SCRIPT_DIR" | awk 'NR == 2 { print $4 }')"
[[ "$available_kb" =~ ^[0-9]+$ ]] || die "could not determine free disk space"
(( available_kb >= MIN_FREE_KB )) || die "at least 4 GiB of free disk space is required"

log "verifying package contents"
bash "$SCRIPT_DIR/verify.sh"

if ! command -v docker >/dev/null 2>&1; then
    die $'Docker is required. Install it manually, then rerun deploy.sh:\n  curl -fsSL https://get.docker.com -o get-docker.sh\n  sh get-docker.sh --dry-run\n  sh get-docker.sh'
fi
docker compose version >/dev/null 2>&1 \
    || die "Docker Compose plugin is missing; install Docker Engine with the Compose plugin, then rerun deploy.sh"
docker buildx version >/dev/null 2>&1 \
    || die "Docker Buildx plugin is missing; install docker-buildx-plugin, then rerun deploy.sh"
command -v openssl >/dev/null 2>&1 \
    || die "OpenSSL is required to generate Freqtrade credentials; install openssl, then rerun deploy.sh"
docker info >/dev/null 2>&1 \
    || die "Docker daemon is not running or root cannot access it; start Docker and rerun deploy.sh"

dotenv_value() {
    local key=$1
    [[ -f .env ]] || return 0
    awk -F= -v key="$key" '
        $1 ~ "^[[:space:]]*" key "[[:space:]]*$" {
            value = substr($0, index($0, "=") + 1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
            print value
            exit
        }
    ' .env
}

if [[ -e .env ]]; then
    [[ -f .env ]] || die ".env exists but is not a regular file"
    grep -Eq '^FREQTRADE_API_PASSWORD=replace-with-' .env \
        && die ".env still contains the password placeholder"
    grep -Eq '^FREQTRADE_JWT_SECRET=replace-with-' .env \
        && die ".env still contains the JWT placeholder"
    had_env=1
else
    had_env=0
fi

containers="$(docker ps --all --format '{{.Names}}|{{.Image}}|{{.State}}')"
npm_candidates=()
npm_states=()
npm_image_pattern='(^|/)jc21/nginx-proxy-manager([:@]|$)'
while IFS='|' read -r name image state; do
    [[ -n "$name" ]] || continue
    if [[ "$name" == npm || "$image" =~ $npm_image_pattern ]]; then
        npm_candidates+=("$name")
        npm_states+=("$state")
    fi
done <<< "$containers"

if ((${#npm_candidates[@]} == 0)); then
    die "Nginx Proxy Manager was not found. Install and start it on this Docker host, then rerun deploy.sh"
fi
if ((${#npm_candidates[@]} > 1)); then
    printf -v candidates_display '%s ' "${npm_candidates[@]}"
    die "multiple Nginx Proxy Manager containers were found (${candidates_display% }); keep one running and remove or rename the others before retrying"
fi
npm_container="${npm_candidates[0]}"
[[ "${npm_states[0]}" == running ]] \
    || die "Nginx Proxy Manager container '$npm_container' is ${npm_states[0]}; start it, then rerun deploy.sh"

proxy_network="$(dotenv_value PROXY_NETWORK)"
proxy_network="${proxy_network:-coinanalysis_proxy}"
[[ "$proxy_network" =~ ^[A-Za-z0-9_.-]+$ ]] \
    || die "PROXY_NETWORK must contain only letters, numbers, dots, underscores or hyphens"
export PROXY_NETWORK="$proxy_network"

build_sha="$(sed -nE 's/^[[:space:]]*"commit_sha"[[:space:]]*:[[:space:]]*"([0-9a-f]{40})"[[:space:]]*,?[[:space:]]*$/\1/p' BUILD-MANIFEST.json | head -n 1)"
build_version="$(sed -nE 's/^[[:space:]]*"version"[[:space:]]*:[[:space:]]*"([^"]+)"[[:space:]]*,?[[:space:]]*$/\1/p' BUILD-MANIFEST.json | head -n 1)"
build_epoch="$(sed -nE 's/^[[:space:]]*"source_date_epoch"[[:space:]]*:[[:space:]]*([0-9]+)[[:space:]]*,?[[:space:]]*$/\1/p' BUILD-MANIFEST.json | head -n 1)"
[[ "$build_sha" =~ ^[0-9a-f]{40}$ ]] || die "the package manifest has no usable commit SHA"
[[ "$build_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "the package manifest has no usable version"
[[ "$build_epoch" =~ ^[0-9]+$ ]] || die "the package manifest has no usable source timestamp"
export COINANALYSIS_COMMIT_SHA="$build_sha"
export COINANALYSIS_VERSION="$build_version"
export COINANALYSIS_SOURCE_DATE_EPOCH="$build_epoch"

log "ensuring Docker network $proxy_network exists"
if ! docker network inspect "$proxy_network" >/dev/null 2>&1; then
    docker network create "$proxy_network" >/dev/null
fi
network_members="$(docker network inspect "$proxy_network" --format '{{range .Containers}}{{println .Name}}{{end}}')" \
    || die "could not inspect Docker network $proxy_network"
if printf '%s\n' "$network_members" | grep -Fxq "$npm_container"; then
    log "Nginx Proxy Manager container $npm_container is already connected to $proxy_network"
else
    log "connecting Nginx Proxy Manager container $npm_container to $proxy_network"
    docker network connect "$proxy_network" "$npm_container"
    network_members="$(docker network inspect "$proxy_network" --format '{{range .Containers}}{{println .Name}}{{end}}')" \
        || die "could not verify Nginx Proxy Manager network connection"
    printf '%s\n' "$network_members" | grep -Fxq "$npm_container" \
        || die "Nginx Proxy Manager did not join Docker network $proxy_network"
fi

if (( had_env )); then
    chmod 600 .env
    log "keeping existing .env"
else
    log "creating .env with fresh Freqtrade credentials"
    cp .env.example .env
    api_password="$(openssl rand -hex 32)"
    jwt_secret="$(openssl rand -hex 32)"
    sed -i "s|^FREQTRADE_API_PASSWORD=.*$|FREQTRADE_API_PASSWORD=$api_password|" .env
    sed -i "s|^FREQTRADE_JWT_SECRET=.*$|FREQTRADE_JWT_SECRET=$jwt_secret|" .env
    chmod 600 .env
fi

backup_stamp="$(date -u +%Y%m%dT%H%M%SZ)"
backup_dir="$SCRIPT_DIR/.deploy-backups/$backup_stamp"
if [[ -e "$backup_dir" ]]; then
    backup_dir="${backup_dir}-$$"
fi
install -d -m 700 "$backup_dir"
if (( had_env )); then
    cp -p .env "$backup_dir/.env"
    chmod 600 "$backup_dir/.env"
fi
cp -p compose.yaml "$backup_dir/compose.yaml"
cp -p BUILD-MANIFEST.json "$backup_dir/BUILD-MANIFEST.json"
log "saved deployment backup in ${backup_dir#$SCRIPT_DIR/}"

install -d -m 0750 data
log "validating Compose configuration"
docker compose config --quiet

log "building and starting services"
docker compose up -d --build --remove-orphans

wait_for_collector() {
    local deadline=$((SECONDS + HEALTH_TIMEOUT_SECONDS))
    local container status
    while (( SECONDS < deadline )); do
        container="$(docker compose ps -q collector 2>/dev/null | head -n 1 || true)"
        if [[ -n "$container" ]]; then
            status="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}no-healthcheck{{end}}' "$container" 2>/dev/null || true)"
            case "$status" in
                healthy) return 0 ;;
                unhealthy)
                    docker compose logs --tail=80 collector >&2 || true
                    die "collector healthcheck reported unhealthy"
                    ;;
            esac
        fi
        sleep 5
    done
    docker compose ps >&2 || true
    docker compose logs --tail=80 collector >&2 || true
    die "collector did not become healthy within ${HEALTH_TIMEOUT_SECONDS}s"
}

log "waiting for collector health"
wait_for_collector

wait_for_service_running() {
    local service=$1
    local deadline=$((SECONDS + SERVICE_START_TIMEOUT_SECONDS))
    local stable_since=""
    local container status

    while (( SECONDS < deadline )); do
        container="$(docker compose ps -q "$service" 2>/dev/null | head -n 1 || true)"
        if [[ -n "$container" ]]; then
            status="$(docker inspect --format '{{.State.Status}}' "$container" 2>/dev/null || true)"
            if [[ "$status" == running ]]; then
                if [[ -z "$stable_since" ]]; then
                    stable_since=$SECONDS
                elif (( SECONDS - stable_since >= 10 )); then
                    return 0
                fi
            else
                stable_since=""
                if [[ "$status" == exited || "$status" == dead ]]; then
                    docker compose logs --tail=80 "$service" >&2 || true
                    die "$service container exited with status $status"
                fi
            fi
        fi
        sleep 2
    done

    docker compose ps >&2 || true
    docker compose logs --tail=80 "$service" >&2 || true
    die "$service did not remain running for 10 seconds within ${SERVICE_START_TIMEOUT_SECONDS}s"
}

for service in dashboard freqtrade; do
    log "waiting for $service to stay running"
    wait_for_service_running "$service"
done

docker compose ps
log "installed build version"
docker compose exec -T collector python -m market_observer --version || true
log "recent collector logs"
docker compose logs --tail=20 collector || true
log "Nginx Proxy Manager is connected to $proxy_network"
log "deployment complete; existing .env and data/ were preserved"
